import 'package:flutter/material.dart';
import 'package:task1_register/login.dart';
import 'package:flutter_svg/flutter_svg.dart';


class rigister extends StatelessWidget {
  const rigister({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      debugShowCheckedModeBanner: false,

      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.grey,
        ),
        backgroundColor: Colors.white,
        body: Center(
          child: SafeArea(
            child: Center(
              child: Column(

                mainAxisAlignment: MainAxisAlignment.center,
                children: [


                  Row(
                    mainAxisAlignment: MainAxisAlignment.start, // تحديد محاذاة الصف
                    children: [
                      BackButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => LogIn(),
                            ),
                          );
                          // تنفيذ الإجراءات عند النقر على زر الرجوع
                        },
                      ),
                      // أي عناصر أخرى تحتاجها هنا
                    ],
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 5),
                    child: Text(
                      "Register Account",
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 5),
                    child: const Text(
                      "Complete your details or continue",
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 5),
                    child: const Text(
                      "with social media",
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                  Form(

                    child: Column(

                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        TextFormField(
                          decoration: InputDecoration(
                            labelText: 'Email',
                            hintText: 'Enter your email',
                            prefixIcon: Icon(Icons.email),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30.0),
                            ),
                          ),
                        ),

                        SizedBox(
                          height: 25,
                        ),
                        TextFormField(
                          decoration:InputDecoration(
                            labelText: 'password',
                            hintText: 'Enter your password',
                            prefixIcon: Icon(Icons.lock),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30.0),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 25,
                        ),
                        TextFormField(
                          decoration: InputDecoration(
                            labelText: 'confim password',
                            hintText: 'Re-enter your password',
                            prefixIcon: Icon(Icons.lock),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30.0),
                            ),
                          ),
                        ),

                        SizedBox(
                          height: 25,
                        ),

                     Center(
                       child: MaterialButton(
                         onPressed: () {},
                          shape: StadiumBorder(),
                          color: Colors.orange,
                          textColor: Colors.white,
                           child: Text("Continue"),
                              height: 40,
                              minWidth: 300,),
                     ),
                        SizedBox(
                          height: 25,
                        ),
                      ],

                    ),





                  ),



                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,

                    children: [
                      Center(
                        child: MaterialButton(
                          onPressed: () {},
                          shape: CircleBorder(),
                          color: Colors.grey.shade50,
                          textColor: Colors.lightBlue,
                          child: Icon(Icons.facebook),
                          height: 40,
                          minWidth: 40,
                        ),
                      ),
                      Center(
                        child: MaterialButton(
                          onPressed: () {},
                          shape: CircleBorder(),
                          color: Colors.grey.shade50,
                          textColor: Colors.lightBlue,
                          child: Icon(Icons.g_mobiledata_outlined),
                          height: 40,
                          minWidth: 40,
                        ),
                      ),
                      Center(
                        child: SvgPicture.asset(
                          'images/twitter.svg',
                          width: 40,
                          height: 40,
                          color: Colors.lightBlue,
                        ),
                      ),
                      SizedBox(
                        height: 25,
                      ),



                    ],

                  ),

                  Container(

                    margin: EdgeInsets.symmetric(vertical: 5),
                    child: const Text(
                      " BY programmer Najlaa ",
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.black54,
                      ),
                    ),
                  ),


                ],

              ),


            ),

          ),
        ),
      ),
    );
  }
  }
